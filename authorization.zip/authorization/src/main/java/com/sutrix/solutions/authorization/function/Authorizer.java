package com.sutrix.solutions.authorization.function;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sutrix.solutions.authorization.model.AuthorizationAction;
import com.sutrix.solutions.authorization.model.AuthorizationContext;
import com.sutrix.solutions.authorization.model.AuthorizationEffect;
import com.sutrix.solutions.authorization.model.AuthorizationPolicy;
import com.sutrix.solutions.authorization.model.AuthorizationStatement;
import com.sutrix.solutions.authorization.model.AuthorizerRequest;
import com.sutrix.solutions.authorization.model.AuthorizerResponse;

public class Authorizer implements RequestHandler<AuthorizerRequest, AuthorizerResponse> {

	private static final Gson gson = new GsonBuilder()
										.setPrettyPrinting()
										.disableHtmlEscaping().create();

	@Override
	public AuthorizerResponse handleRequest(AuthorizerRequest input, Context context) {

		String token = input.getAuthorizationToken();
		String version = "2012-10-17";
		String principalId = "arn:aws:iam::245210236097:k1gd599k92";

		AuthorizerResponse response = new AuthorizerResponse();
		AuthorizationPolicy policy = new AuthorizationPolicy();
		policy.Version = version;
		AuthorizationStatement authStatement = new AuthorizationStatement();
		response.setPrincipalId(principalId);
		authStatement.Action = AuthorizationAction.INVOKE.get();
		authStatement.Resource = input.getMethodArn();

		if (token != null) {
			authStatement.Effect = AuthorizationEffect.Allow;
			 AuthorizationContext authContext = new AuthorizationContext();
			 authContext.setStringKey("sampleString");
			 authContext.setNumberKey("1"); // sample number
			 authContext.setBooleanKey("true"); // sample boolean
			 response.setContext(authContext);
		} else {
			authStatement.Effect = AuthorizationEffect.Deny;
		}
		
		policy.add(authStatement);
		response.setPolicyDocument(policy);
		
		context.getLogger().log("Json response's value: " + gson.toJson(response));
		
		return response;
	}
}