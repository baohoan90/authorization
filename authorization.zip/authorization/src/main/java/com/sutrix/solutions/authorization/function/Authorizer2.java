package com.sutrix.solutions.authorization.function;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sutrix.solutions.authorization.model.AuthorizerRequest;
import com.sutrix.solutions.authorization.model.authorization2.AuthPolicy;

public class Authorizer2 implements RequestHandler<AuthorizerRequest, AuthPolicy> {

	private static final Gson gson = new GsonBuilder().create();

	@Override
	public AuthPolicy handleRequest(AuthorizerRequest input, Context context) {

		String json = "{ \"principalId\": \"arn:aws:iam::245210236097:k1gd599k92\", \"policyDocumentObject\": { \"Version\": \"2018-08-08\", \"allowStatement\": { \"Effect\": \"Allow\", \"Action\": \"execute-api:Invoke\", \"Condition\": {}, \"resourceList\": [ \"arn:aws:execute-api:ap-southeast-1:245210236097:k1gd599k92/dev/GET/pets\" ] }, \"statements\": [ { \"Effect\": \"Allow\", \"Action\": \"execute-api:Invoke\", \"Condition\": {}, \"resourceList\": [ \"arn:aws:execute-api:ap-southeast-1:245210236097:k1gd599k92/dev/GET/pets\" ] } ] } }";
		AuthPolicy authPolicy = gson.fromJson(json, AuthPolicy.class);
		context.getLogger().log(gson.toJson(authPolicy));
		return authPolicy;
	}

	public static void main(String[] args) {
		String json = "{\"principalId\": \"arn:aws:iam::245210236097:k1gd599k92\",\"policyDocumentObject\": {\"Version\": \"2018-08-08\",\"allowStatement\": {\"Effect\": \"Allow\",\"Action\": \"execute-api:Invoke\",\"Condition\": {},\"resourceList\": []},\"statements\": [{\"Effect\": \"Allow\",\"Action\": \"execute-api:Invoke\",\"Condition\": {},\"resourceList\": [ \"arn:aws:execute-api:ap-southeast-1:245210236097:k1gd599k92/dev/GET/pets\" ]}]}}";
		AuthPolicy authPolicy = gson.fromJson(json, AuthPolicy.class);
		System.out.println(gson.toJson(authPolicy));
	}
}
