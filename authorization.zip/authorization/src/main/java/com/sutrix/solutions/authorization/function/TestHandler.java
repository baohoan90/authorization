package com.sutrix.solutions.authorization.function;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.sns.model.InternalErrorException;
import com.amazonaws.util.StringUtils;
import com.sutrix.solutions.authorization.entity.User;

public class TestHandler implements RequestHandler<User, Object> {

	@Override
	public Object handleRequest(User input, Context context) {

		if (StringUtils.isNullOrEmpty(input.getId())) {
			throw new BadRequestException("Missing user id");
		}

		if (StringUtils.isNullOrEmpty(input.getName())) {
			throw new InternalErrorException("Internal Error");
		}
		
		return "OK";
	}

}
