package com.sutrix.solutions.authorization.function;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.util.StringUtils;
import com.sutrix.solutions.authorization.model.GenerateTokenRequest;
import com.sutrix.solutions.authorization.model.GenerateTokenResponse;

public class TokenGenerateHandler implements RequestHandler<GenerateTokenRequest, GenerateTokenResponse> {

	@Override
	public GenerateTokenResponse handleRequest(GenerateTokenRequest input, Context context) {

		validateInput(input);
		GenerateTokenResponse response = new GenerateTokenResponse();
		if (verifyUser(input)) {
			response.setToken(
					"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6Ik5pa28gS8O2YmxlciIsImFkbWluIjp0cnVlLCJpc3MiOiJkYXNuaWtvIiwiYXVkIjoiZGVtbyJ9.V7vQT0N6Py-n9mjRgt-QwWMsTSvFkTRRU0D5t1lrS08");
			return response;
		}
		response.setToken("");
		return response;

	}

	private void validateInput(GenerateTokenRequest input) {
		if (input == null) {
			throw new RuntimeException("Invalid Request");
		}
		if (StringUtils.isNullOrEmpty(input.getUsername())) {
			throw new RuntimeException("Missing username");
		}
		if (StringUtils.isNullOrEmpty(input.getEncodedPassword())) {
			throw new RuntimeException("Missing password");
		}
	}

	private boolean verifyUser(GenerateTokenRequest input) {
		return input != null;
	}

}
