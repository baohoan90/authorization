package com.sutrix.solutions.authorization.function.cognito;

import java.util.HashMap;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentity;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentityClient;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentityClientBuilder;
import com.amazonaws.services.cognitoidentity.model.GetCredentialsForIdentityRequest;
import com.amazonaws.services.cognitoidentity.model.GetOpenIdTokenForDeveloperIdentityRequest;
import com.amazonaws.services.cognitoidentity.model.GetOpenIdTokenForDeveloperIdentityResult;

public class CognitoHelper {
	
	public String getIdentityIdToken() {

        // initialize the Cognito identity client with a set
        // of anonymous AWS credentials
        AmazonCognitoIdentityClientBuilder identityClientBuilder = AmazonCognitoIdentityClient.builder()
                .withCredentials(new AWSCredentialsProvider() {

                    @Override
                    public void refresh() {
                        // TODO Auto-generated method stub

                    }

                    @Override
                    public AWSCredentials getCredentials() {
                        // TODO Auto-generated method stub
                        return new BasicAWSCredentials(UserPoolSettings.getAWSAccessKey(), UserPoolSettings.getAWSSecretkey());
                    }
                });

        identityClientBuilder.setRegion(Regions.EU_CENTRAL_1.getName());

        AmazonCognitoIdentity identityClient = identityClientBuilder.build();

        // send a get id request. This only needs to be executed the first time
        // and the result should be cached.
//        GetOpenIdTokenForDeveloperIdentityRequest tokenRequest = new GetOpenIdTokenForDeveloperIdentityRequest();
//        tokenRequest.setIdentityPoolId("ap-southeast-1:9fdb6d39-afff-46ee-8185-97863e32976d");

        HashMap<String, String> map = new HashMap<>();
        map.put("login.com....", "myUser");
//        tokenRequest.setLogins(map);
        
        AWSCredentials credential = new BasicAWSCredentials(UserPoolSettings.getAWSAccessKey(), UserPoolSettings.getAWSSecretkey());
        
//        GetCredentialsForIdentityRequest tokenRequest = new GetCredentialsForIdentityRequest();
//        tokenRequest.setLogins(map);
//        tokenRequest.setRequestCredentials(credentials);
//        tokenRequest.setIdentityId("ap-southeast-1:9fdb6d39-afff-46ee-8185-97863e32976d");
//
//        GetOpenIdTokenForDeveloperIdentityResult result = identityClient.getCredentialsForIdentity(arg0)
//                .getOpenIdTokenForDeveloperIdentity(tokenRequest);

//        return result.getToken();
        return "";
    }
}
