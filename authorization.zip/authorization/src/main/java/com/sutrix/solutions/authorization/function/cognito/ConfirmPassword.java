package com.sutrix.solutions.authorization.function.cognito;

import java.util.HashMap;
import java.util.Map;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClient;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AdminRespondToAuthChallengeRequest;
import com.amazonaws.services.cognitoidp.model.AdminRespondToAuthChallengeResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.ChallengeNameType;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.util.StringUtils;
import com.sutrix.solutions.authorization.entity.AccountLogin;

public class ConfirmPassword implements RequestHandler<AccountLogin, String>{

	private AWSCognitoIdentityProvider cognitoClient = null;
	
	public String confirm(String username,String password, String session){
		 String idToken = null;
		 Map<String,String> challengeResponses = new HashMap<>();
		 challengeResponses.put("USERNAME", username);
		 challengeResponses.put("PASSWORD", password);
		 challengeResponses.put("NEW_PASSWORD", password);
		 AdminRespondToAuthChallengeRequest finalRequest = new AdminRespondToAuthChallengeRequest()
		     .withChallengeName(ChallengeNameType.NEW_PASSWORD_REQUIRED)
		     .withChallengeResponses(challengeResponses)
		     .withClientId(UserPoolSettings.getClientId())
		     .withUserPoolId(UserPoolSettings.getUserPoolId())
		     .withSession(session);
		 AdminRespondToAuthChallengeResult challengeResponse = getCognitoClient().adminRespondToAuthChallenge(finalRequest);
		 if(StringUtils.isNullOrEmpty(challengeResponse.getChallengeName())){
		   idToken = challengeResponse.getAuthenticationResult().getIdToken();
		 }
		 return idToken;
		}

		private AWSCognitoIdentityProvider getCognitoClient(){
		 if(cognitoClient == null) {
		   cognitoClient = AWSCognitoIdentityProviderClient.builder()
		       .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(UserPoolSettings.getAWSAccessKey(),
		    		   UserPoolSettings.getAWSSecretkey()))).withRegion(Regions.AP_SOUTHEAST_1).build();
		 }
		 return cognitoClient;
		}

		@Override
		public String handleRequest(AccountLogin input, Context context) {
			
			AWSCognitoIdentityProvider client = getCognitoClient();
			HashMap<String, String> authParams = new HashMap<>();
			authParams.put("USERNAME", input.getUsername());
			authParams.put("PASSWORD", input.getPassword());
			
			StringBuilder contentLogs = new StringBuilder();
			contentLogs.append("ClientId ").append(UserPoolSettings.getClientId()).append(" - ")
			.append("UserPoolId: ").append(" - ")
					.append(AuthFlowType.USER_SRP_AUTH).append("-")
					.append(" AuthoParams: ").append(authParams);
			context.getLogger().log(contentLogs.toString());
			
			AdminInitiateAuthRequest adminInitiateAuthRequest = new AdminInitiateAuthRequest()
					.withClientId(UserPoolSettings.getClientId())
					.withUserPoolId(UserPoolSettings.getUserPoolId())
					.withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH).withAuthParameters(authParams);
			
			AdminInitiateAuthResult result = client.adminInitiateAuth(adminInitiateAuthRequest);
			
			return confirm(input.getUsername(), input.getPassword(), result.getSession());			
		}
}
