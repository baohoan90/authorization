package com.sutrix.solutions.authorization.function.cognito;

import java.util.HashMap;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentity;
import com.amazonaws.services.cognitoidentity.model.GetIdRequest;
import com.amazonaws.services.cognitoidentity.model.GetIdResult;
import com.amazonaws.services.cognitoidentity.model.GetOpenIdTokenRequest;
import com.amazonaws.services.cognitoidentity.model.GetOpenIdTokenResult;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClient;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.AuthenticationResultType;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.util.StringUtils;
import com.google.gson.Gson;
import com.sutrix.solutions.authorization.entity.AccountLogin;

public class SignIn implements RequestHandler<AccountLogin, AuthenticationResultType> {

	private AmazonCognitoIdentity identityClient = null;
	private AWSCognitoIdentityProvider cognitoClient = null;

	private String getClientId() {
		String clientId = System.getenv("CLIENT_ID");
		return StringUtils.isNullOrEmpty(clientId) ? "" : clientId;
	}

	private AWSCognitoIdentityProvider getCognitoClient() {

		if (cognitoClient == null) {
			cognitoClient = AWSCognitoIdentityProviderClient.builder()
					.withCredentials(
							new AWSStaticCredentialsProvider(new BasicAWSCredentials(UserPoolSettings.getAWSAccessKey(), UserPoolSettings.getAWSSecretkey())))
					.withRegion(Regions.AP_SOUTHEAST_1).build();
		}
		return cognitoClient;
	}

	
	@Override
	public AuthenticationResultType handleRequest(AccountLogin input, Context context) {

		// initialize the Cognito identity client with a set
		// of anonymous AWS credentials

		AWSCognitoIdentityProvider client = getCognitoClient();
		HashMap<String, String> authParams = new HashMap<>();
		authParams.put("USERNAME", input.getUsername());
		authParams.put("PASSWORD", input.getPassword());
		
		StringBuilder contentLogs = new StringBuilder();
		contentLogs.append("ClientId ").append(getClientId()).append(" - ")
		.append("UserPoolId: ").append(" - ")
				.append(AuthFlowType.USER_SRP_AUTH).append("-")
				.append(" AuthoParams: ").append(authParams);
		context.getLogger().log(contentLogs.toString());
		
		AdminInitiateAuthRequest adminInitiateAuthRequest = new AdminInitiateAuthRequest()
				.withClientId(getClientId())
				.withUserPoolId(UserPoolSettings.getUserPoolId())
				.withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH).withAuthParameters(authParams);
		
		AdminInitiateAuthResult result = client.adminInitiateAuth(adminInitiateAuthRequest);
		
		if (result != null) {
			System.out.println("AdminInitiateAuthResult:");
			context.getLogger().log(new Gson().toJson(result));
			result.getAuthenticationResult();
		} else {
			System.out.println("No result available");
		}

		return null;
	}

	/*
	 * Call the GetId API providing your AWS account and identity pool details to
	 * retrieve a unique identifier for your end user.
	 *
	 */
	private String getId(String awsAccountId, String awsUserPoolId) {

		// send a get id request. This only needs to be executed the first time
		// and the result should be cached.
		GetIdRequest idRequest = new GetIdRequest();
		idRequest.setAccountId(awsAccountId);
		idRequest.setIdentityPoolId(awsUserPoolId);
		// If you are authenticating your users through an identity provider
		// then you can set the Map of tokens in the request
		// Map providerTokens = new HashMap();
		// providerTokens.put("graph.facebook.com", "facebook session key");
		// idRequest.setLogins(providerTokens);

		GetIdResult idResp = identityClient.getId(idRequest);

		String identityId = idResp.getIdentityId();

		// TODO: At this point you should save this identifier so you won't
		// have to make this call the next time a user connects
		return identityId;
	}

	private String getOpenIdToken(String identityId) {
		// Create the request object
		GetOpenIdTokenRequest tokenRequest = new GetOpenIdTokenRequest();
		tokenRequest.setIdentityId(identityId);
		// If you are authenticating your users through an identity provider
		// then you can set the Map of tokens in the request
		// Map providerTokens = new HashMap();
		// providerTokens.put("graph.facebook.com", "facebook session key");
		// tokenRequest.setLogins(providerTokens);

		GetOpenIdTokenResult tokenResp = identityClient.getOpenIdToken(tokenRequest);
		// get the OpenID token from the response
		String openIdToken = tokenResp.getToken();
		return openIdToken;
	}

	// private void AssumeRoleWithWebIdentity() {
	// // you can now create a set of temporary, limited-privilege credentials to
	// access
	// // your AWS resources through the Security Token Service utilizing the OpenID
	// // token returned by the previous API call. The IAM Role ARN passed to this
	// call
	// // will be applied to the temporary credentials returned
	// AWSSecurityTokenService stsClient = new AWSSecurityTokenServiceClient(new
	// AnonymousAWSCredentials());
	// AssumeRoleWithWebIdentityRequest stsReq = new
	// AssumeRoleWithWebIdentityRequest();
	// stsReq.setRoleArn("arn:aws:iam::6157xxxxxxxx:role/a_valid_aws_role_arn");
	// stsReq.setWebIdentityToken(awsAccessToken);
	// stsReq.setRoleSessionName("AppTestSession");
	//
	// AssumeRoleWithWebIdentityResult stsResp =
	// stsClient.assumeRoleWithWebIdentity(stsReq);
	// Credentials stsCredentials = stsResp.getCredentials();
	//
	// // Create the session credentials object
	// AWSSessionCredentials sessionCredentials = new BasicSessionCredentials(
	// stsCredentials.getAccessKeyId(),
	// stsCredentials.getSecretAccessKey(),
	// stsCredentials.getSessionToken()
	// );
	// // save the timeout for these credentials
	// Date sessionCredentialsExpiration = stsCredentials.getExpiration();
	//
	// // these credentials can then be used to initialize other AWS clients,
	// // for example the Amazon Cognito Sync client
	// AmazonCognitoSync syncClient = new
	// AmazonCognitoSyncClient(sessionCredentials);
	// ListDatasetsRequest syncRequest = new ListDatasetsRequest();
	// syncRequest.setIdentityId(idResp.getIdentityId());
	// syncRequest.setIdentityPoolId("YOUR_COGNITO_IDENTITY_POOL_ID");
	// ListDatasetsResult syncResp = syncClient.listDatasets(syncRequest);
	// }
}
