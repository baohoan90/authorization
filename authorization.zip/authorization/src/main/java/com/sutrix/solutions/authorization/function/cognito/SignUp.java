package com.sutrix.solutions.authorization.function.cognito;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.apigateway.model.TooManyRequestsException;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClient;
import com.amazonaws.services.cognitoidp.model.AdminCreateUserRequest;
import com.amazonaws.services.cognitoidp.model.AttributeType;
import com.amazonaws.services.cognitoidp.model.DeliveryMediumType;
import com.amazonaws.services.cognitoidp.model.UsernameExistsException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.sutrix.solutions.authorization.entity.AccountLogin;

public class SignUp implements RequestHandler<AccountLogin, String>{
	
	private AWSCognitoIdentityProvider cognitoClient = null;

	private AWSCognitoIdentityProvider getCognitoClient() {

		if (cognitoClient == null) {
			cognitoClient = AWSCognitoIdentityProviderClient.builder()
					.withCredentials(
							new AWSStaticCredentialsProvider(new BasicAWSCredentials(UserPoolSettings.getAWSAccessKey(), UserPoolSettings.getAWSSecretkey())))
					.withRegion(Regions.AP_SOUTHEAST_1).build();
		}
		return cognitoClient;
	}
	
	@Override
	public String handleRequest(AccountLogin input, Context context) {
		cognitoClient = getCognitoClient();
		try
		{
		    AdminCreateUserRequest cognitoRequest = new AdminCreateUserRequest()
		            .withUserPoolId(UserPoolSettings.getUserPoolId())
		            .withUsername(input.getUsername())
		            .withTemporaryPassword(input.getPassword())
		            .withUserAttributes(
		                    new AttributeType()
		                        .withName("email")
		                        .withValue("hoan.lamthanhbao@gmail.com"),
		                    new AttributeType()
		                        .withName("email_verified")
		                        .withValue("true"))
		            .withDesiredDeliveryMediums(DeliveryMediumType.EMAIL)
		            .withForceAliasCreation(Boolean.FALSE);

		    cognitoClient.adminCreateUser(cognitoRequest);
		    
		}
		catch (UsernameExistsException ex)
		{
		    context.getLogger().log("user already exists: " + ex.getMessage());
		}
		catch (TooManyRequestsException ex)
		{
			 context.getLogger().log("caught TooManyRequestsException, delaying then retrying");
		}
		return null;
	}

}
