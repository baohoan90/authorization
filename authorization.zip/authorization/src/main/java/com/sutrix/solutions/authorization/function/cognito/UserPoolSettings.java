package com.sutrix.solutions.authorization.function.cognito;

public class UserPoolSettings {

	private UserPoolSettings() {
	}

	public static String getUserPoolId() {
		return System.getenv("USER_POOL_ID");
	}

	public static String getClientId() {
		return System.getenv("CLIENT_ID");
	}

	public static String getAWSAccessKey() {
		return "AKIAJDNA2AD2FBPUNYSA";
	}

	public static String getAWSSecretkey() {
		return "aor29+UjG4rfi5kRDIv1V4L8nOy+49zHGjwZjP/S";
	}
}
