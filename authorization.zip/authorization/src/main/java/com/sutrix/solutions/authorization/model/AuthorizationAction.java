package com.sutrix.solutions.authorization.model;

public enum AuthorizationAction {

	INVOKE("execute-api:Invoke");

	AuthorizationAction(String action) {
		this.action = action;
	}

	private String action;

	public String get() {
		return this.action;
	}
}
