package com.sutrix.solutions.authorization.model;

public enum AuthorizationEffect {
	Allow, Deny;
}
