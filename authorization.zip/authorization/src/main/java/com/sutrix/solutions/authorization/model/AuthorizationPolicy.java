package com.sutrix.solutions.authorization.model;

import java.util.LinkedList;
import java.util.List;

public class AuthorizationPolicy {

	public String Version;
	public List<AuthorizationStatement> Statement = new LinkedList<>();

	public AuthorizationPolicy() {
	}
	
	public void add(AuthorizationStatement statement) {
		this.Statement.add(statement);
	}
}