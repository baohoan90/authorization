package com.sutrix.solutions.authorization.model;

public class AuthorizationStatement {

	public String Action;
	public AuthorizationEffect Effect;
	public String Resource;
}
