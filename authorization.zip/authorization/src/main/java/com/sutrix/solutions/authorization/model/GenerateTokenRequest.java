package com.sutrix.solutions.authorization.model;

import java.io.Serializable;

public class GenerateTokenRequest implements Serializable {

	private static final long serialVersionUID = 1432993458635127229L;

	private String username;
	private String encodedPassword;
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the encodedPassword
	 */
	public String getEncodedPassword() {
		return encodedPassword;
	}
	/**
	 * @param encodedPassword the encodedPassword to set
	 */
	public void setEncodedPassword(String encodedPassword) {
		this.encodedPassword = encodedPassword;
	}

}
