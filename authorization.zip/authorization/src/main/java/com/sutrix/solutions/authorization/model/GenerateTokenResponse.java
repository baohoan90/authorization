package com.sutrix.solutions.authorization.model;

import java.io.Serializable;

public class GenerateTokenResponse implements Serializable {

	private static final long serialVersionUID = 1432993458635127229L;

	private String token;

	public GenerateTokenResponse() {
		this.token = "";
	}

	public GenerateTokenResponse(String token) {
		this.token = token;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token
	 *            the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
}
