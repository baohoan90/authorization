package com.sutrix.solutions.authorization.model.authorization2;

public class AWSRequest {

	private String payload;

	/**
	 * @return the payload
	 */
	public String getPayload() {
		return payload;
	}

	/**
	 * @param payload the payload to set
	 */
	public void setPayload(String payload) {
		this.payload = payload;
	}

}
