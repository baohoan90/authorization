package com.sutrix.solutions.authorization.model.authorization2;

import java.io.Serializable;

public class ArnMethod implements Serializable {

	private static final long serialVersionUID = -5877580857517162507L;

	// region, awsAccountId, restApiId, stage, method, resource
	private String region;
	private String awsAccountId;
	private String restApiId;
	private String stage;
	private String method;
	private String resoure;

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region
	 *            the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the awsAccountId
	 */
	public String getAwsAccountId() {
		return awsAccountId;
	}

	/**
	 * @param awsAccountId
	 *            the awsAccountId to set
	 */
	public void setAwsAccountId(String awsAccountId) {
		this.awsAccountId = awsAccountId;
	}

	/**
	 * @return the restApiId
	 */
	public String getRestApiId() {
		return restApiId;
	}

	/**
	 * @param restApiId
	 *            the restApiId to set
	 */
	public void setRestApiId(String restApiId) {
		this.restApiId = restApiId;
	}

	/**
	 * @return the stage
	 */
	public String getStage() {
		return stage;
	}

	/**
	 * @param stage
	 *            the stage to set
	 */
	public void setStage(String stage) {
		this.stage = stage;
	}

	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}

	/**
	 * @param method
	 *            the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}

	/**
	 * @return the resoure
	 */
	public String getResoure() {
		return resoure;
	}

	/**
	 * @param resoure
	 *            the resoure to set
	 */
	public void setResoure(String resoure) {
		this.resoure = resoure;
	}
}
