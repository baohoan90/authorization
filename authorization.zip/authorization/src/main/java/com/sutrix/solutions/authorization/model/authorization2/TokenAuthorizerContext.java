package com.sutrix.solutions.authorization.model.authorization2;

public class TokenAuthorizerContext {

	private String type;
	private String authorizationToken;
	private String methodArn;

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the authorizationToken
	 */
	public String getAuthorizationToken() {
		return authorizationToken;
	}

	/**
	 * @param authorizationToken the authorizationToken to set
	 */
	public void setAuthorizationToken(String authorizationToken) {
		this.authorizationToken = authorizationToken;
	}

	/**
	 * @return the methodArn
	 */
	public String getMethodArn() {
		return methodArn;
	}

	/**
	 * @param methodArn the methodArn to set
	 */
	public void setMethodArn(String methodArn) {
		this.methodArn = methodArn;
	}
}
